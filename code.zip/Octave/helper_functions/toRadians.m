function rads = toRadians(degrees)
	rads = degrees * pi / 180;
