%takes meters and converts to astronomical units
function aus = meterToAu(meters)
	aus = meters / auToMeter(1);
