%Takes a distance in astronomical units and converts it to meters
function meter = auToMeter(aus)
	meter = aus * 149597870700;
